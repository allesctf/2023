module.exports = [
    {
        id: '0',
        title: 'A important note',
        body:
            'Lorem ipsum dolor sit amet, pro eu aperiam sensibus adolescens, pri eu nostrum electram expetendis. Mel unum possim vocent ei. Eos nemore euripidis ea, ne inani regione alienum his. Ex esse justo est, aliquip eligendi sit ut, an vis alii ferri viderer. Ne vis graeco dictas. Nam aeque equidem facilisi te, nec eu oratio equidem singulis.'
    },
    {
        id: '1',
        title: 'An other note',
        body:
            'Mel unum possim vocent ei. Eos nemore euripidis ea, ne inani regione alienum his. Ex esse justo est, aliquip eligendi sit ut, an vis alii ferri viderer. Ne vis graeco dictas. Nam aeque equidem facilisi te, nec eu oratio equidem singulis.'
    },
    {
        id: '2',
        title: 'A third note',
        body:
            'Ne vis graeco dictas. Nam aeque equidem facilisi te, nec eu oratio equidem singulis. Mel unum possim vocent ei. Eos nemore euripidis ea, ne inani regione alienum his. Ex esse justo est, aliquip eligendi sit ut, an vis alii ferri viderer. '
    },
    {
        id: '3',
        title: 'A final note',
        body:
            'Nam aeque equidem facilisi te, nec eu oratio equidem singulis. Mel unum possim vocent ei. Eos nemore euripidis ea, ne inani regione alienum his. Ex esse justo est, aliquip eligendi sit ut, an vis alii ferri viderer. '
    }
];
