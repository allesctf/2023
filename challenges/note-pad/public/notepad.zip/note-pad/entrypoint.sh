
REACT_APP_API_ROOT=https://${SESSIONID}-1024-note-pad.${CHALLENGE_DOMAIN}:31337 node server/server.js