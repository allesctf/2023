window.config = {
  SKIP_PREFLIGHT_CHECK: "true",
  REACT_APP_API_ROOT: "http://localhost:4000",
  REACT_APP_ROOT: "http://localhost:3000",
}
