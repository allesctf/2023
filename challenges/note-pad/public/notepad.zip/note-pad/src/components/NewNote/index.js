export { default } from './NewNote';
