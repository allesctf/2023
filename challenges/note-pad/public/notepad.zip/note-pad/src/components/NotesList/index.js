export { default } from './NotesList';
