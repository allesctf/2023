#!/bin/bash
dropbear -FBREkwp 1024
